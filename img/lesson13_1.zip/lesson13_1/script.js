const image = document.querySelector('img');
const input = document.querySelector('input');

input.addEventListener('input', (event) => {
    image.width = 10 * event.target.value
})