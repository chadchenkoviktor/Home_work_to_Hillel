const input = document.querySelector("input");
const list = document.querySelectorAll("li");

const checkValue = (value, regExp, item) => {
  if (regExp.test(value)) {
    item.style.color = "green";
  } else {
    item.style.color = "red";
  }
};

const validateValue = (event) => {
  const value = event.target.value;

  checkValue(value, /[A-Z]/, list[0]);
  checkValue(value, /\d/, list[1]);
  checkValue(value, /[\.,\-!\?]/, list[2]);
  checkValue(value, /.{8,}/, list[3]);
};

input.addEventListener("input", validateValue);
